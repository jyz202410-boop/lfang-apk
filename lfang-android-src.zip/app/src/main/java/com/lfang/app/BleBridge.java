package com.lfang.app;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.UUID;

/**
 * D2 的蓝牙桥：WebView 里没有 Web Bluetooth，所以这里用原生 BLE 读，
 * 再把读数通过 evaluateJavascript 推给网页。
 */
public class BleBridge {

    private static final UUID SVC = UUID.fromString("3ab10100-f831-4395-b29d-570977d5bf94");
    private static final UUID MEAS = UUID.fromString("3ab10101-f831-4395-b29d-570977d5bf94");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final Context ctx;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothGatt gatt;
    private boolean connecting = false;
    private boolean permitted = true;

    public BleBridge(Context context, WebView webView) {
        this.ctx = context;
        this.web = webView;
    }

    /* ---------------- 给网页调的方法 ---------------- */

    @JavascriptInterface
    public boolean isAvailable() {
        return hasPermission() && adapter() != null && adapter().isEnabled();
    }

    @JavascriptInterface
    public void start() {
        ui.post(this::startInternal);
    }

    @JavascriptInterface
    public void stop() {
        ui.post(this::stopInternal);
    }

    @JavascriptInterface
    public String deviceName() {
        return gatt != null && gatt.getDevice() != null && gatt.getDevice().getName() != null
                ? gatt.getDevice().getName() : "";
    }

    /* ---------------- 内部 ---------------- */

    private BluetoothAdapter adapter() {
        BluetoothManager m = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        return m == null ? null : m.getAdapter();
    }

    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void onPermissionsChanged(boolean granted) {
        permitted = granted;
        if (!granted) emitState("idle", "没有蓝牙权限，请在系统设置里允许「附近的设备」");
    }

    @SuppressLint("MissingPermission")
    private void startInternal() {
        if (!hasPermission()) {
            emitState("idle", "没有蓝牙权限，请在系统设置里允许「附近的设备」");
            return;
        }
        BluetoothAdapter ad = adapter();
        if (ad == null) { emitState("idle", "这台手机没有蓝牙"); return; }
        if (!ad.isEnabled()) { emitState("idle", "手机蓝牙没打开"); return; }
        if (connecting) return;

        scanner = ad.getBluetoothLeScanner();
        if (scanner == null) { emitState("idle", "蓝牙扫描不可用"); return; }

        emitState("connecting", "正在搜索 D2…");

        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int type, ScanResult result) {
                BluetoothDevice dev = result.getDevice();
                if (dev == null) return;
                String name = dev.getName() == null ? "" : dev.getName();
                boolean byName = name.contains("DISTO") || name.contains("D2") || name.contains("Leica");
                boolean byService = result.getScanRecord() != null
                        && result.getScanRecord().getServiceUuids() != null
                        && result.getScanRecord().getServiceUuids().contains(new android.os.ParcelUuid(SVC));
                if (byName || byService) {
                    stopScan();
                    connect(dev);
                }
            }
        };

        scanner.startScan(scanCallback);
        ui.postDelayed(() -> {
            if (connecting) return;
            emitState("idle", "没搜到 D2：确认仪器蓝牙已开、长按蓝牙键，且没连着别的手机");
            stopScan();
        }, 12000);
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        try {
            if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback);
        } catch (Exception ignored) { }
        scanner = null;
        scanCallback = null;
    }

    @SuppressLint("MissingPermission")
    private void connect(BluetoothDevice dev) {
        connecting = true;
        emitState("connecting", "正在连接 " + (dev.getName() == null ? "D2" : dev.getName()) + "…");
        gatt = dev.connectGatt(ctx, false, new BluetoothGattCallback() {
            @Override
            public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    g.discoverServices();
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connecting = false;
                    emitState("idle", "连接已断开");
                }
            }

            @Override
            public void onServicesDiscovered(BluetoothGatt g, int status) {
                BluetoothGattService svc = g.getService(SVC);
                if (svc == null) {
                    emitState("idle", "这台设备没有 D2 的测量服务");
                    g.disconnect();
                    return;
                }
                BluetoothGattCharacteristic ch = svc.getCharacteristic(MEAS);
                if (ch == null) {
                    emitState("idle", "没找到测量特征值");
                    g.disconnect();
                    return;
                }
                g.setCharacteristicNotification(ch, true);
                BluetoothGattDescriptor d = ch.getDescriptor(CCCD);
                if (d != null) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    } else {
                        d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        g.writeDescriptor(d);
                    }
                }
                connecting = false;
                emitState("connected", g.getDevice().getName() == null ? "D2" : g.getDevice().getName());
            }

            @Override
            public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic ch) {
                handleValue(ch.getValue());
            }

            @Override
            public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic ch, byte[] value) {
                handleValue(value);
            }
        });
    }

    private void handleValue(byte[] v) {
        if (v == null || v.length < 4) return;
        float raw = ByteBuffer.wrap(v).order(ByteOrder.LITTLE_ENDIAN).getFloat();
        if (Float.isNaN(raw) || raw < 0) return;
        final String js = "window.__lfangBLE&&window.__lfangBLE.emit(" + raw + ")";
        ui.post(() -> web.evaluateJavascript(js, null));
    }

    private void emitState(String state, String msg) {
        final String js = "window.__lfangBLE&&window.__lfangBLE.state('" + state + "','"
                + (msg == null ? "" : msg.replace("'", "\\'")) + "')";
        ui.post(() -> web.evaluateJavascript(js, null));
    }

    @SuppressLint("MissingPermission")
    private void stopInternal() {
        stopScan();
        connecting = false;
        try {
            if (gatt != null) { gatt.close(); gatt = null; }
        } catch (Exception ignored) { }
    }
}
