package com.lfang.app;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * 文件桥：WebView 里 <a download> 不工作，所以导出交给原生来写。
 * 两条路：存到系统「下载」，或者直接走系统分享（微信/邮件）。
 */
public class FileBridge {

    private final Context ctx;

    public FileBridge(Context context) {
        this.ctx = context;
    }

    @JavascriptInterface
    public boolean available() {
        return true;
    }

    /** 存到「下载」文件夹，返回一个给人看的路径，失败返回 ERR:xxx */
    @JavascriptInterface
    public String save(String name, String mime, String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "ERR:系统拒绝创建文件";
                OutputStream os = ctx.getContentResolver().openOutputStream(uri);
                if (os == null) return "ERR:无法写入文件";
                os.write(data);
                os.close();
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                ctx.getContentResolver().update(uri, done, null, null);
                return "下载/" + name;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists() && !dir.mkdirs()) return "ERR:没有存储权限";
            File f = new File(dir, name);
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(data);
            fos.close();
            return "下载/" + name;
        } catch (Exception e) {
            return "ERR:" + e.getClass().getSimpleName() + " " + e.getMessage();
        }
    }

    /** 直接调系统分享面板（微信、邮件、发送到电脑） */
    @JavascriptInterface
    public String share(String name, String mime, String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            File dir = new File(ctx.getCacheDir(), "share");
            if (!dir.exists() && !dir.mkdirs()) return "ERR:无法创建缓存目录";
            File f = new File(dir, name);
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(data);
            fos.close();

            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Intent chooser = Intent.createChooser(send, "发送 " + name);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            ctx.startActivity(chooser);
            return "OK";
        } catch (Exception e) {
            return "ERR:" + e.getClass().getSimpleName() + " " + e.getMessage();
        }
    }
}
